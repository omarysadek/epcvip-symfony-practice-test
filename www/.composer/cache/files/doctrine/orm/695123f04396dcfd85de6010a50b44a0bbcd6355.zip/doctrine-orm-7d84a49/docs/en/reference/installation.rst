Installation
============

The installation chapter has moved to :doc:`Installation and Configuration <reference/configuration>`_.
