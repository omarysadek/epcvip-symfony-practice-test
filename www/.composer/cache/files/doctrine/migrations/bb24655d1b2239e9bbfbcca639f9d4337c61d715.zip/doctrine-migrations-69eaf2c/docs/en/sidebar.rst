.. toctree::
   :depth: 3

   reference/introduction
   reference/configuration
   reference/migration-classes
   reference/managing-migrations
   reference/generating-migrations
   reference/custom-configuration
   reference/events
   reference/version-numbers
   reference/integrations
   reference/custom-integration
