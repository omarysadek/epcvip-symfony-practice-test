# Doctrine Migrations

[![Build Status](https://travis-ci.org/doctrine/migrations.svg)](https://travis-ci.org/doctrine/migrations)
[![Code Coverage](https://codecov.io/gh/doctrine/migrations/branch/master/graph/badge.svg)](https://codecov.io/gh/doctrine/migrations/branch/master)

## Documentation

All available documentation can be found [here](https://www.doctrine-project.org/projects/migrations.html).
