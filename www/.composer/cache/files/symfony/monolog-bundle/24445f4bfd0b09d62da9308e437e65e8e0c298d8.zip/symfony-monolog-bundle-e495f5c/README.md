MonologBundle
=============

The `MonologBundle` provides integration of the [Monolog](https://github.com/Seldaek/monolog)
library into the Symfony framework.

More information in the official [documentation](http://symfony.com/doc/current/cookbook/logging/index.html).

License
=======

This bundle is released under the [MIT license](LICENSE)
