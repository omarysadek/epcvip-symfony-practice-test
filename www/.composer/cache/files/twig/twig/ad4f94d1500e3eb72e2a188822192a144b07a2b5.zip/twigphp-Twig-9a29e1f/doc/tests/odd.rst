``odd``
=======

``odd`` returns ``true`` if the given number is odd:

.. code-block:: twig

    {{ var is odd }}

.. seealso:: :doc:`even<../tests/even>`
