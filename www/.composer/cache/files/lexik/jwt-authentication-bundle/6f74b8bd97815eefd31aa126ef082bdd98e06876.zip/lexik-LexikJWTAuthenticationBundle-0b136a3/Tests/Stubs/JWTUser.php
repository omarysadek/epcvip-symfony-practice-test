<?php

namespace Lexik\Bundle\JWTAuthenticationBundle\Tests\Stubs;

use Lexik\Bundle\JWTAuthenticationBundle\Security\User\JWTUser as BaseUser;

final class JWTUser extends BaseUser
{
}
